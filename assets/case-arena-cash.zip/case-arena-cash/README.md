# Case Arena Cash — conta digital + cartão

**Uma empresa, um funil.** Augment e Connect leem recortes diferentes do mesmo kit.

**Nome:** **Arena Cash**. Em conversa às vezes aparece “Cache”; o canônico é Cash.

## O funil (não são dois produtos)

| Elo | O que é | Onde a sala usa |
|---|---|---|
| Signup | Cadastro na conta | Contexto (acima da meta no Q1) |
| **Ativação** | 1ª transação no cartão em 30 dias | **Augment** — 38% → 24% |
| **Uso recorrente** | % dos ativados que usam o cartão nas primeiras semanas | **Connect** — leading (sobe) |
| **Cartão principal** | % dos ativos que concentram o gasto mensal aqui | **Connect** — outcome (cai) |
| **Interchange / cliente ativo** | Receita de bandeira por ativo | **Connect** — impact (cai) |

Armadilha da manhã: o PM quer mais onboarding porque o signup subiu e a ativação caiu.  
Armadilha da tarde: uso nas primeiras semanas parece saudável; o cartão não vira o principal e o interchange por cabeça cai.

Números-chave Augment: ativação **38%→24%** · churn **4,2%→6,8%** · NPS **52→41** · CAC **R$120→R$180**.

Números-chave Connect (fim Q1 vs início, ordem de grandeza no CSV): uso recorrente **sobe**; cartão principal **cai** (~24%→15% no Free); interchange por ativo **cai** (R$ 15,5→11 no Free). Receita total de interchange no xlsx ainda sobe — volume esconde unit economics.

## Arquivos

| Arquivo | Para quê |
|---|---|
| `memo-estrategico-q2.md` | Brief principal |
| `dados-semanais-arenacash.csv` | Série semanal (ativação + caminho do cartão) |
| `dados-quarter-q1.csv` | Quarter |
| `atendimento-*.csv` | Sinais de suporte (cartão / conta / KYC) |
| `financeiro-q1.xlsx` | Spread + interchange vs CAC |
| `organograma-arenacash.md` | Contexto de time |
| `transcricao-c*.md` | Voz dos C-levels |
| `design-system-arenacash.md` | Visual |
| `logo/arena-cash.png` | Logo (paleta Arena: #FF494C + preto) |
| `_generate_arenacash_datasets.py` | Regenerar dados (não precisa na sala) |

## Brief de sala (Augment)

**Pronto:** [../07-brief-sala-arena-cash.md](../07-brief-sala-arena-cash.md)  
**Slides:** [../slides-wip/15-case-arena-cash.md](../slides-wip/15-case-arena-cash.md)

**Tese típica do PM:** expandir onboarding (mais IA) porque signups subiram e ativação caiu.

Pegue Cash se o seu mundo é fintech / conta / cartão / pagamentos.
