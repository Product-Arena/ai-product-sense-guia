# Case Arena Cash — cópia para AI Product Sense

**Decisão:** cópia **independente**. O conteúdo deste curso não depende do Cursor para PMs em runtime. Edits de sala, brief e dinâmica ficam **só aqui**.

**Origem da cópia (referência histórica):**  
`repos/cursor-para-pms/case arenacash/`  
(espelho também em `learning/Cursor para PMs por Product Arena/case arenacash/`)

**Uso neste curso:**
1. **Augment** — construir a skill Devil's Advocate e aplicar em onboarding / ativação.
2. **Build / Connect** — opção fintech do trio Match / Pipeline / Cash (mesma pasta; sem segundo case fintech).

**Nome:** **Arena Cash** (fintech). Em conversa às vezes aparece “Cache”; o canônico é Cash.

## O que veio na cópia

| Arquivo | Para quê |
|---|---|
| `memo-estrategico-q2.md` | Brief principal: ativação 38%→24%, churn, NPS, CAC |
| `dados-semanais-arenacash.csv` | Números semanais |
| `dados-quarter-q1.csv` | Quarter |
| `atendimento-*.csv` | Sinais de suporte |
| `financeiro-q1.xlsx` | Financeiro |
| `organograma-arenacash.md` | Contexto de time |
| `transcricao-c*.md` | Voz dos C-levels |
| `design-system-arenacash.md` | Visual (menos crítico no Augment) |
| `logo/arena-cash.png` | Logo fictício (paleta Arena: #FF494C + preto) |
| `_generate_arenacash_datasets.py` | Regenerar dados (não precisa na sala) |

## Brief de sala (Augment)

**Pronto:** [../07-brief-sala-arena-cash.md](../07-brief-sala-arena-cash.md)  
**Slides:** [../slides-wip/15-case-arena-cash.md](../slides-wip/15-case-arena-cash.md)

Números-chave: ativação **38%→24%** · churn **4,2%→6,8%** · NPS **52→41** · CAC **R$120→R$180**.

**Tese típica do PM:** expandir onboarding (mais IA) porque signups subiram e ativação caiu.

**Músculo do Think:** mesmo do FlowUp; produto diferente. Transcripts C-level = opcional pós-aula.
