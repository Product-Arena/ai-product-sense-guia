# Case Arena Match — marketplace de serviços

**Uso:** Start my day (Build) e Connect.  
Subtítulo interno: serviços conectados (encanador, eletricista, diarista, etc.).

## Números verdade

| Métrica | ~Semana 0 / início | ~Semana 4 / fim Q1 |
|---|---|---|
| Buscas / sem (ordem de grandeza) | **42k** | **48k+** |
| % busca → contato | **18%** | **24%** |
| % contato → contratação | **31%** | **29%** |
| GMV (semanal, ordem) | **R$ 2,1 mi** | **R$ 2,3 mi** |
| Take rate | **12%** | **12%** |
| Cancelamento pós-contato | subindo com o contato | |

**Tese:** matching inteligente (3 recomendações em vez de lista infinita) aumenta contratação.

**Armadilha:** leading (contato) sobe; outcome (contratação) cai.

## Arquivos

| Arquivo | Para quê |
|---|---|
| `memo-estrategico-q2.md` | CEO |
| `organograma-arena-match.md` | Você = PM de Matching & Conversão |
| `transcricao-c*.md` | C-levels |
| `dados-semanais-arena-match.csv` | Série semanal |
| `dados-quarter-q1.csv` | Mensal |
| `funil-marketing-arena-match.csv` | Aquisição → busca |
| `atendimento-*.csv` | “Se perde na lista” |
| `financeiro-q1.xlsx` | Take / GMV |
| `logo/arena-match.png` | Logo fictício (paleta Arena) |

Pegue Match se o seu mundo é marketplace / two-sided.
