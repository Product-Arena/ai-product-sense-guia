# Memo estratégico — Q2 2026
**De:** Diego Vargas, CEO & Co-fundador  
**Para:** Time Arena Match  
**Data:** 30 de março de 2026  
**Assunto:** Busca sobe. Contratação não acompanha.

---

Equipe,

Volume de busca está bom. **Busca → contato foi de ~18% para ~24%.** Parece vitória de lista e de ads. Só que **contato → contratação caiu de ~31% para ~29%.** GMV sobe pouco. CS repete: o cliente “se perde na lista”.

Take rate 12% sobre GMV só escala se a contratação fechar. Contato sem match é custo de suporte e de reputação do profissional.

## Três apostas

1. **Subir busca → contratação** sem piorar cancelamento pós-contato. Squad Matching & Conversão.
2. **Testar matching em 3 recomendações** vs lista infinita, com coorte.
3. **Não escalar CAC** enquanto a conversão do meio estiver caindo.

Fora: nova vertical de produtos físicos, app só para profissional no Q2.

Diego
