# Organograma Arena Match
**Atualizado em:** 30 de março de 2026  
**Headcount:** ~40

## O que é

Marketplace que conecta quem precisa de serviço a quem presta. Receita = **take rate** sobre GMV.

## C-level

| Nome | Cargo |
|---|---|
| **Diego Vargas** | CEO & Co-fundador |
| **Camila Freitas** | CTO |
| **Renato Pires** | CFO |
| **Juliana Azevedo** | CMO |
| **Felipe Costa** | CPO |

## Squad prioritário Q2 — Matching & Conversão

| Nome | Cargo |
|---|---|
| **[Você]** | PM |

Outros: Supply (profissionais), Growth, Trust & Safety.
