# Transcrição — Renato Pires (CFO)
**Data:** 3 de abril de 2026

**Renato:** GMV sem take realizado é vaidade. Eu olho receita de take e margem após suporte. Se matching subir contato e subir cancelamento, o P&L piora. Experiência: coorte, custo de CS por contato, take líquido.
