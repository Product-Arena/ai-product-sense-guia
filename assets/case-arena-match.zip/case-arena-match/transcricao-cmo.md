# Transcrição — Juliana Azevedo (CMO)
**Data:** 2 de abril de 2026

**Juliana:** Eu consigo trazer busca. O que eu não consigo é defender CAC se contato sobe e contratação cai. Hipótese: lista longa aumenta clique em “falar com profissional” e piora a qualidade do match. Quero o teste das 3 recomendações com métrica de contratação e de cancelamento — não só contato.
