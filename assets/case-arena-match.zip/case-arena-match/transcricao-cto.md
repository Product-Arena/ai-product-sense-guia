# Transcrição — Camila Freitas (CTO)
**Data:** 3 de abril de 2026

**Camila:** Ranking em 3 slots: temos features de distância, nota e taxa de resposta. Não precisa de modelo novo no dia 1 — regra + experimento A/B. Modelo ML no Q3 se o A/B mostrar ganho estável. Trust & Safety precisa veto se o matching empurrar profissional com restrição.
