# Case Arena Pipeline — SaaS B2B CRM / vendas

**Uso:** exercício Think (piloto Free → Paid, 30 dias) + Start my day (Build) e Connect.  
**Arena Cash** = Augment. **Pipeline** = este case (SaaS B2B).

## Números verdade — piloto Think (self-serve)

Fonte: `piloto-onboarding-ia-30d.csv`. Contas fecham com o slide do Dudu.

| Comparação | Números |
|---|---|
| O que o PM mostrou | Free → Paid **3,2% → 5,1%** (**+59%**) |
| Segmento tratado, histórico | **4,8%** |
| Comparação honesta | **4,8% → 5,1%** (**+0,3 p.p.**) |

Quem entrou no piloto já convertia acima da média da base. Não há controle no material.

## Números verdade — funil Q1 (Build)

| Métrica | Baseline (Mar / coorte) | Meta Q2 / piloto onboarding IA |
|---|---|---|
| Trial → paid | **12%** | **13%** (não é a aposta) |
| Pipeline operando em 7 dias | **22%** | **40%** |
| Adoção (critério interno) 30d | **18%** | **30%** |
| NRR 90d | **94%** | ainda cedo para cravar; acompanhar |
| Churn logo mensal | **3,4%** | **2,5%** |

**Tese:** onboarding assistido por IA que monta o primeiro pipeline com contexto da empresa.

**Armadilha (Build):** leading lindo; impact (NRR) ainda não dá para cravar.  
**Armadilha (Think):** comparar o piloto com a média da empresa, não com o histórico do mesmo segmento.

## Arquivos

| Arquivo | Para quê |
|---|---|
| `memo-estrategico-q2.md` | CEO / fundadora |
| `organograma-arena-pipeline.md` | Você = PM de Activation & NRR |
| `transcricao-c*.md` | C-levels |
| `dados-semanais-arena-pipeline.csv` | Série semanal |
| `dados-quarter-q1.csv` | Mensal |
| `piloto-onboarding-ia-30d.md` / `.csv` | Think: Free → Paid 3,2% / 5,1% / 4,8% |
| `funil-marketing-arena-pipeline.csv` | MQL → SQL → trial → paid |
| `atendimento-*.csv` | Setup / integração |
| `financeiro-q1.xlsx` | Assinatura / CAC |
| `logo/arena-pipeline.png` | Logo fictício (paleta Arena) |

Pegue Pipeline se o seu mundo é SaaS B2B, CRM ou vendas.
