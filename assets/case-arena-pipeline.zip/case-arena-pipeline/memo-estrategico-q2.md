# Memo estratégico — Q2 2026
**De:** Andréa Lima, CEO & Co-fundadora  
**Para:** Time Arena Pipeline  
**Data:** 30 de março de 2026  
**Assunto:** Trial converte. Conta não opera. NRR não perdoa.

---

Time,

Fechamos o Q1 com ARR subindo no gráfico e um problema que o gráfico esconde: **só 22% das contas pagas têm pipeline operando em 7 dias.** Adoção no critério interno aos 30 dias: **18%**. Trial → paid está estável em **12%** — o comercial entrega logo; o produto não entrega o segundo dia.

NRR 90d em **94%**. Churn de logo em **3,4%**. CS está lotado de “não sei configurar o primeiro pipeline”.

## Por que agora

Série A olha NRR e tempo até valor, não só new logo. Se a gente escalar outbound com adoção de 18%, a gente compra churn.

## Três apostas

1. **Pipeline operando em 7 dias: 22% → 40%.** Squad Activation & NRR.
2. **Adoção 30d: 18% → 30%.** Mesmo squad + CS.
3. **Segurar CAC e new logo sem piorar mix.** Marketing não compra trial que não configura.

Fora do Q2: marketplace de integrações, mobile app nativo, rebrand.

## PMs

Hipótese falsificável, coorte de controle, não vender NRR como prova em 30 dias. Leading pode ser pipeline em 7d; lagging continua NRR — e o Devil's Advocate vai perguntar se quem adotou já ia adotar.

Andréa
