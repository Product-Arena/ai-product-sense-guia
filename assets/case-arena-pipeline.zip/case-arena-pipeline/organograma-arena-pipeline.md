# Organograma Arena Pipeline
**Atualizado em:** 30 de março de 2026  
**Headcount:** ~55

## O que é

SaaS B2B de **CRM / vendas em movimento**. Assinatura anual. Receita boa em **retenção e expansão (NRR)**.

## C-level

| Nome | Cargo |
|---|---|
| **Andréa Lima** | CEO & Co-fundadora |
| **Bruno Teixeira** | CTO |
| **Patrícia Gomes** | CFO |
| **Leo Martins** | CMO |
| **Inês Rocha** | CPO |

## Squad prioritário Q2 — Activation & NRR

| Nome | Cargo |
|---|---|
| **[Você]** | PM |
| Tech lead, eng, design, dados, CS embed | |

Outros: Core CRM, Integrações, Growth/PLG.
