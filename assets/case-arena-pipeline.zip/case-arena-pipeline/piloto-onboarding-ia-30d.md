# Piloto — onboarding com IA (30 dias)

**Uso:** exercício Think (Dudu). No Build, o funil comercial continua em `dados-quarter-q1.csv` (trial → paid ~12%).

**Produto:** Arena Pipeline — SaaS B2B (CRM / vendas).  
**Plano do piloto:** self-serve Free → Paid (PLG), não o trial assistido pelo comercial.

O time lançou um onboarding com IA para ajudar a configurar o produto e chegar mais rápido ao primeiro valor. Objetivo declarado: subir Free → Paid.

## O que o PM apresentou (30 dias)

| | Antes | Depois |
|---|---|---|
| Free → Paid | **3,2%** | **5,1%** |

Conclusão do PM: “A conversão aumentou 59%. O onboarding com IA funcionou. Vamos expandir para 100% da base.”

Contas no CSV: 10.000 free na base (320 paid = 3,2%); 2.000 no piloto (102 paid = 5,1%).

## O que o PM não mostrou no primeiro slide

Quem recebeu o novo onboarding era de um **segmento que historicamente já convertia 4,8%** (96 paid em 2.000 no histórico do mesmo segmento).

| Comparação | Números |
|---|---|
| O que parecia | 3,2% → 5,1% (**+59%**) |
| Comparação honesta | 4,8% → 5,1% (**+0,3 p.p.**) |

Não há grupo de controle no material. Não dá para atribuir o +0,3 p.p. ao onboarding — nem afirmar que o onboarding falhou.

## Duas métricas, dois funis

| Funil | Onde está | O que é |
|---|---|---|
| Free → Paid (PLG) | este arquivo + CSV | Exercício Think |
| Trial → paid (~12%) | `dados-quarter-q1.csv` | Comercial / Build |
