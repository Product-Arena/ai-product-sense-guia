# Transcrição — Patrícia Gomes (CFO)
**Data:** 3 de abril de 2026

**Patrícia:** CAC em ~R$ 4,7k com NRR 94% e churn subindo não fecha a tese de Série B. Eu aceito investir em onboarding IA se o experimento tiver **grupo de controle** e se ninguém reportar NRR de 30 dias como vitória.

Leading que eu compro: % com pipeline operando em 7 dias. Lagging: NRR da coorte em 90 dias. Qualquer slide que misture os dois eu devolvo.
