# Transcrição — Leo Martins (CMO)
**Data:** 2 de abril de 2026

**Leo:** MQL e SQL estão ok. Trial sobe. O buraco é pós-signup: a pessoa assina e some. Eu não vou pedir mais outbound até pipeline em 7d sair de 22%.

**Hipóteses:** (1) onboarding é tour de produto, não monta pipeline com o contexto da empresa; (2) SE vendeu “CRM completo” e o time de vendas do cliente nunca abriu a ferramenta; (3) integração Gmail/Calendar falha no dia 1 e mata o hábito.

**Pedido:** onboarding assistido que cria o primeiro pipeline de verdade. Meça em coorte — se só melhora quem já tinha ops de vendas madura, é seleção.
