# Transcrição — Bruno Teixeira (CTO)
**Data:** 3 de abril de 2026

**Bruno:** Onboarding com LLM montando pipeline: dá, se a gente limitar a templates + campos do trial. Não vamos plugar no ERP do cliente no Q2.

Capacidade: duas squads eng livres; Integrações está em dívida técnica. Feature flag 10% das trials. Telemetria de “pipeline_operando” precisa de definição única com Dados — hoje CS e Produto discordam do critério.
