---
name: map-product-impact
description: "Mapear iniciativas, hipóteses e problemas de produto em uma cadeia causal até receita, custo ou margem. Usar ao decidir o que construir, investigar uma métrica, definir uma tese, criar uma árvore de métricas, avaliar impacto de uma iniciativa ou transformar métricas de produto em indicadores de negócio e leading/lagging indicators."
---

# Mapear Impacto de Produto

Atuar como parceiro crítico de decisão, não como gerador de dashboards. Produzir o menor mapa de métricas que sustente a decisão e declarar premissas ou lacunas de evidência.

## Começar pela decisão

Identificar a decisão a tomar, o público afetado, o horizonte de tempo e o trade-off. Distinguir pedido de solução, problema e hipótese.

Se faltar contexto essencial, pedir apenas o que impede o mapa: modelo de negócio, decisão, iniciativa ou problema, e métrica ou resultado desejado. Se houver contexto suficiente, prosseguir e rotular premissas explícitas.

Escrever uma tese falsificável:

> Acreditamos que **[intervenção]** para **[público]** mudará **[comportamento]**, gerará **[resultado de produto]** e contribuirá para **[impacto econômico]**. Consideraremos a tese válida ou inválida quando **[critério, prazo e comparação]**.

Não tratar intuição, feedback positivo, ou um número isolado como evidência de impacto.

## Mapear a alavanca econômica

Identificar primeiro como a iniciativa pode importar para o negócio. Usar `references/alavancas-economicas.md` para orientar o raciocínio, sem transformar a análise em uma lista exaustiva de métricas.

Classificar cada alavanca em uma rota principal:

- **Aumentar ou preservar receita:** aquisição, conversão, ticket, frequência, retenção, expansão, monetização.
- **Reduzir custos ou proteger margem:** custo de servir, operação e suporte, COGS/CMV, perdas, incentivos, custo de aquisição ou custo de comunicação.

Adaptar a linguagem ao modelo de negócio. Por exemplo, pedidos e take rate em marketplace; MRR, expansão e churn em SaaS; interchange em fintech. Não assumir que o mapa de SaaS serve a todo produto.

Selecionar no máximo uma métrica de impacto para a decisão e apenas as métricas intermediárias necessárias para explicar o caminho até ela. Definir cada métrica antes de usá-la: população, evento, denominador, janela e fonte quando disponível.

## Construir a árvore de impacto

Mapear a cadeia completa:

```text
Tese -> Input -> Output -> Outcome -> Impacto
       intervenção  comportamento  resultado  indicador econômico
```

- **Input:** o que entrou no produto ou na operação.
- **Output:** comportamento que as pessoas passaram a ter.
- **Outcome:** resultado mensurável dentro do produto.
- **Impacto:** métrica econômica ou financeira que se pretende mover.

Rotular as métricas:

- **Leading:** sinal precoce, acionável e ligado à hipótese; normalmente output ou outcome.
- **Lagging:** resultado definitivo, tardio e menos acionável; normalmente impacto econômico.
- **Controle, influência ou contribuição:** respectivamente, o que o time move diretamente, move com outros times, ou apenas contribui para mover.

Não chamar uma métrica de leading apenas por aparecer cedo. Explicar por que ela é preditiva do impacto e como essa ligação será validada.

## Testar a cadeia antes de recomendar

Separar fatos, inferências e hipóteses. Antes de atribuir causalidade, verificar:

1. Qual evidência sustenta cada elo da cadeia?
2. Qual seria o contrafactual ou grupo de comparação?
3. Que outra explicação ou variável de confusão pode explicar o resultado?
4. Qual comportamento precisa mudar para o impacto ser possível?
5. O que faria abandonar ou revisar a tese?

Não concluir causalidade apenas porque duas métricas se movem juntas. Recomendar o método de validação proporcional à decisão: experimento, holdout, coorte, antes/depois com limitações declaradas, pesquisa qualitativa ou coleta adicional.

## Entregar uma análise curta e acionável

Usar esta estrutura, adaptando o nível de detalhe ao pedido:

### Decisão e tese
- Decisão a tomar e trade-off.
- Tese falsificável e premissas.

### Mapa econômico
| Rota | Métrica de impacto (lagging) | Por que importa |
|---|---|---|
| Receita ou custo/margem | | |

### Árvore de impacto
| Elo | Métrica | Tipo | Responsabilidade | Evidência ou lacuna |
|---|---|---|---|---|
| Input | | | Controle | |
| Output | | Leading | Controle | |
| Outcome | | Leading ou lagging | Influência | |
| Impacto | | Lagging | Contribuição | |

### Decisão recomendada
- **Recomendação:** fazer, não fazer, ajustar ou investigar mais.
- **Confiança:** alta, média ou baixa, com motivo.
- **Próximo passo:** método, owner, horizonte e critério de sucesso ou abandono.

Ser direto. Preferir uma árvore pequena e testável a uma taxonomia completa. Se não houver evidência suficiente, dizer isso claramente e indicar a menor próxima coleta que destrava a decisão.
