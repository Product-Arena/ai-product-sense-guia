# Alavancas econômicas de produto

Usar esta referência para gerar hipóteses de métricas. Selecionar apenas o que for relevante para a decisão; não reproduzir a lista inteira em uma análise.

## Aumentar ou preservar receita

| Alavanca | Exemplos de impacto | Possíveis métricas de produto |
|---|---|---|
| Aquisição | novos clientes, pedidos ou receita nova | visita para cadastro, cadastro para ativação, CAC, leads qualificados |
| Conversão | pedidos, vendas, receita por visita | busca para compra, checkout, aprovação de pagamento, task success |
| Ticket e monetização | ticket médio, ARPA, take rate, receita por pedido | escolha de plano, attach rate, upgrade, add-on, preço aceito |
| Frequência e retenção | pedidos recorrentes, MRR/GMV recorrente, LTV | reativação, repetição, adoção de funcionalidade, uso recorrente |
| Expansão | upsell, cross-sell, expansão de receita | contas elegíveis, oferta vista, conversão de upgrade |
| Preservação | menor churn de clientes ou receita | motivos de cancelamento, health score, tickets críticos, qualidade percebida |

## Reduzir custos ou proteger margem

| Alavanca | Exemplos de impacto | Possíveis métricas de produto ou operação |
|---|---|---|
| Custo de servir | custo por pedido, transação ou conta ativa | automação, self-service, taxa de sucesso sem intervenção humana |
| Suporte e operação | custo de atendimento, tempo operacional | tickets, contato por usuário, tempo de resolução, deflexão |
| COGS/CMV | margem bruta, custo variável | custo logístico, cloud/IA por tarefa, custo de fornecedor, perdas |
| Incentivos e perdas | margem de contribuição, reembolso, fraude | uso de cupom, cancelamento, estorno, chargeback, fraude evitada |
| Comunicação e aquisição | custo de comunicação ou CAC | mensagens por conversão, entregabilidade, custo por lead/pedido |

## Adaptação por modelo de negócio

- **Marketplace:** conectar demanda, oferta, matching, conversão, ticket/GMV, take rate, custo variável e margem de contribuição. Avaliar os dois lados do mercado.
- **SaaS/B2B:** conectar aquisição, ativação, adoção, retenção, expansão, MRR/ARR e custo de servir. Distinguir churn de clientes de churn de receita.
- **Fintech:** conectar ativação, uso recorrente, volume transacionado, receita por transação/interchange, inadimplência/fraude e custo de atendimento.
- **Produto com IA:** explicitar custo por tarefa, taxa de sucesso, escalonamento humano, qualidade e adoção. Ganho de uso sem qualidade ou margem não é impacto comprovado.
